
 grade =50;

if(grade>=90&&grade<98)
{
    console.log("A GRADE");
}
else if(grade>=80&&grade<89)
{
    console.log("B GRADE");
}
else if(grade>=70&&grade<79)
{
    console.log("C GRADE")
}
else if(grade>=60&&grade<69)
{
    console.log("D GRADE")
}
else
{
    console.log("Failed")
}