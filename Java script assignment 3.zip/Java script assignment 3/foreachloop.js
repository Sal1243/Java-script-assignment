


var avengers =[
    {
        name:"captain america",
        age:34,
        power:"shield"

    },
    {
        name:"hulk",
        age:35,
        power:"hand power"

    }

]
avengers.forEach( function(a,i)
{
    console.log(a,i);
}
)  