
var avengers=[
    {
        name:"iron man",
        age :28,
        power:"armour"


    },
    {
        name:"thor",
        age:24,
        power:"stormbeaker"

    }
]  
for(i=0;i<avengers.length;i++)
{
    console.log(avengers[i]);
}
