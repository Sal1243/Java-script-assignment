

var student =[

    {
      name:"salman",
      age:22,
      state:"tamil nadu"

    },
    {
        name:"mohamed",
        age:26,
        state:"tamil nadu"
  
    },
    {
        name:"suhail",
        age:24,
        state:"tamil nadu"
  
    },
    {
        name:"sulaiman",
        age:20,
        state:"tamil nadu"
  
    }
]
 for(i=0;i<student.length;i++)
 {
     console.log(student[i].name,student[i].age,student[i].state)
 }


 